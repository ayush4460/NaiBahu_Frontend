/**
 * Payments API Service
 * All payment-related API calls
 */

import apiClient, { showApiError } from './client';
import { Payment, ProcessPaymentDTO, ApiResponse } from '@/types';

// ============================================
// PAYMENT ENDPOINTS
// ============================================

/**
 * Process payment
 */
export async function processPayment(paymentData: ProcessPaymentDTO): Promise<Payment> {
  try {
    const response = await apiClient.post<ApiResponse<Payment>>('/payments', paymentData);
    return response.data.data;
  } catch (error: any) {
    showApiError(error);
    throw error;
  }
}

/**
 * Get payment by ID
 */
export async function getPaymentById(paymentId: number): Promise<Payment> {
  try {
    const response = await apiClient.get<ApiResponse<Payment>>(`/payments/${paymentId}`);
    return response.data.data;
  } catch (error: any) {
    showApiError(error);
    throw error;
  }
}

/**
 * Get payments by order
 */
export async function getPaymentsByOrder(orderId: number): Promise<Payment[]> {
  try {
    const response = await apiClient.get<ApiResponse<Payment[]>>(
      `/payments?order_id=${orderId}`
    );
    return response.data.data;
  } catch (error: any) {
    showApiError(error);
    throw error;
  }
}

/**
 * Get all payments
 */
export async function getAllPayments(): Promise<Payment[]> {
  try {
    const response = await apiClient.get<ApiResponse<Payment[]>>('/payments');
    return response.data.data;
  } catch (error: any) {
    showApiError(error);
    throw error;
  }
}

// ============================================
// EXPORT
// ============================================

const paymentsApi = {
  processPayment,
  getPaymentById,
  getPaymentsByOrder,
  getAllPayments,
};

export default paymentsApi;